$(function(){
    const search = $('.search-btn');
    const search_container = $('.search-container');
   
    search.click(function(){
       
        search_container.toggleClass('active');
        $(this).toggleClass('active');
    })
  
})